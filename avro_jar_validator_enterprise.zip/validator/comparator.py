from fastavro.schema import compatibility
from jsondiff import diff
from validator.models import FieldDiff

def check_compatibility(old, new, rule):
    if rule == "BACKWARD":
        return compatibility.check_reader_writer_compatibility(new, old)
    if rule == "FORWARD":
        return compatibility.check_reader_writer_compatibility(old, new)
    return (
        compatibility.check_reader_writer_compatibility(new, old)
        and compatibility.check_reader_writer_compatibility(old, new)
    )

def diff_fields(old, new):
    changes = diff(old, new)
    diffs = []
    for k in changes.keys():
        diffs.append(FieldDiff(
            field=str(k),
            change=str(changes[k]),
            severity="BREAKING"
        ))
    return diffs