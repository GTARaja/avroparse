from dataclasses import dataclass
from typing import List

@dataclass
class FieldDiff:
    field: str
    change: str
    severity: str

@dataclass
class SchemaResult:
    class_name: str
    namespace: str
    record: str
    compatible: bool
    rule: str
    diffs: List[FieldDiff]