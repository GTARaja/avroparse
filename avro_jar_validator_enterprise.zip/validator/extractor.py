import subprocess, json, zipfile

AVRO_TOOLS = "tools/avro-tools.jar"

def list_classes(jar):
    with zipfile.ZipFile(jar) as z:
        return [
            c.replace("/", ".").replace(".class", "")
            for c in z.namelist()
            if c.endswith(".class") and "$" not in c
        ]

def extract_schema(jar, class_name):
    cmd = [
        "java", "-jar", AVRO_TOOLS,
        "getschema",
        "--classpath", jar,
        class_name
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
    if result.returncode != 0:
        return None
    return json.loads(result.stdout)