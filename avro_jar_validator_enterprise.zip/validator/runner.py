from validator.extractor import list_classes, extract_schema
from validator.comparator import check_compatibility, diff_fields
from validator.models import SchemaResult

def run_validation(ref_jar, new_jar, rule):
    ref_classes = set(list_classes(ref_jar))
    new_classes = set(list_classes(new_jar))
    common = ref_classes & new_classes

    results = []

    for cls in common:
        old = extract_schema(ref_jar, cls)
        new = extract_schema(new_jar, cls)
        if not old or not new:
            continue

        compatible = check_compatibility(old, new, rule)
        diffs = diff_fields(old, new)

        results.append(SchemaResult(
            class_name=cls,
            namespace=new.get("namespace"),
            record=new.get("name"),
            compatible=compatible,
            rule=rule,
            diffs=diffs
        ))

    return results