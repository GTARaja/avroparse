import pandas as pd

def generate_excel(results, path):
    summary = []
    details = []

    for r in results:
        summary.append({
            "Class": r.class_name,
            "Compatible": r.compatible,
            "Rule": r.rule
        })
        for d in r.diffs:
            details.append({
                "Class": r.class_name,
                "Field": d.field,
                "Change": d.change,
                "Severity": d.severity
            })

    with pd.ExcelWriter(path) as w:
        pd.DataFrame(summary).to_excel(w, "Summary", index=False)
        pd.DataFrame(details).to_excel(w, "Field_Diff", index=False)