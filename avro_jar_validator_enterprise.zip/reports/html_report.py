from jinja2 import Template

def generate_html(results, template_path, output_path):
    with open(template_path) as f:
        tpl = Template(f.read())

    with open(output_path, "w") as f:
        f.write(tpl.render(results=results))