import json
from dataclasses import asdict

def generate_json(results, path):
    with open(path, "w") as f:
        json.dump([asdict(r) for r in results], f, indent=2)