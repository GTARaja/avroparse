from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton,
    QFileDialog, QComboBox, QMessageBox, QApplication
)
import sys
from main import execute

class AvroValidatorUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Enterprise Avro JAR Validator")
        self.setGeometry(300, 200, 500, 300)

        self.ref_jar = None
        self.new_jar = None

        layout = QVBoxLayout()

        self.ref_label = QLabel("Reference JAR: Not selected")
        self.new_label = QLabel("New JAR: Not selected")

        self.rule_box = QComboBox()
        self.rule_box.addItems(["BACKWARD", "FORWARD", "FULL"])

        ref_btn = QPushButton("Select Reference JAR")
        new_btn = QPushButton("Select New JAR")
        validate_btn = QPushButton("Run Validation")

        ref_btn.clicked.connect(self.select_ref)
        new_btn.clicked.connect(self.select_new)
        validate_btn.clicked.connect(self.validate)

        layout.addWidget(self.ref_label)
        layout.addWidget(ref_btn)
        layout.addWidget(self.new_label)
        layout.addWidget(new_btn)
        layout.addWidget(QLabel("Compatibility Rule"))
        layout.addWidget(self.rule_box)
        layout.addWidget(validate_btn)

        self.setLayout(layout)

    def select_ref(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Reference JAR", "", "JAR Files (*.jar)")
        if path:
            self.ref_jar = path
            self.ref_label.setText(f"Reference JAR: {path}")

    def select_new(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select New JAR", "", "JAR Files (*.jar)")
        if path:
            self.new_jar = path
            self.new_label.setText(f"New JAR: {path}")

    def validate(self):
        if not self.ref_jar or not self.new_jar:
            QMessageBox.warning(self, "Error", "Please select both JAR files")
            return

        rule = self.rule_box.currentText()
        out = execute(self.ref_jar, self.new_jar, rule)

        QMessageBox.information(self, "Completed", f"Validation completed. Reports generated in: {out}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = AvroValidatorUI()
    win.show()
    sys.exit(app.exec())