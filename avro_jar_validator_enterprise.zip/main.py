from validator.runner import run_validation
from reports.excel_report import generate_excel
from reports.html_report import generate_html
from reports.json_report import generate_json
from datetime import datetime
import os

def execute(ref_jar, new_jar, rule):
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    out = f"output/{ts}"
    os.makedirs(out, exist_ok=True)

    results = run_validation(ref_jar, new_jar, rule)

    generate_excel(results, f"{out}/report.xlsx")
    generate_html(results, "templates/report.html", f"{out}/report.html")
    generate_json(results, f"{out}/report.json")

    return out