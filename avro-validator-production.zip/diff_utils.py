
def diff_fields(old,new):
    o={f["name"]:f for f in old["fields"]}
    n={f["name"]:f for f in new["fields"]}
    nb=[f"New field added: {f}" for f in n if f not in o]
    return nb,[]
