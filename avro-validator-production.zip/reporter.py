
import json
def write_json_report(r,p): open(p,"w").write(json.dumps(r,indent=2))
def write_html_report(r,p):
    h="<html><body><h1>Avro Report</h1>"
    for s,d in r.items():
        h+=f"<h2>{s}</h2>"
        for k in d:
            if d[k]:
                h+=f"<b>{k}</b><ul>"
                for x in d[k]: h+=f"<li>{x}</li>"
                h+="</ul>"
    h+="</body></html>"; open(p,"w").write(h)
