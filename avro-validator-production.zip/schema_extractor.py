
import zipfile, json
def extract_schemas(path):
    schemas = {}
    with zipfile.ZipFile(path) as z:
        for n in z.namelist():
            if n.endswith(".avsc"):
                s=json.loads(z.read(n).decode())
                k=f"{s.get('namespace','')}.{s['name']}"
                schemas[k]=s
    return schemas
