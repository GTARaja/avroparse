
import sys,json
from PyQt6.QtWidgets import *
from schema_extractor import extract_schemas
from compatibility import check_compatibility
from diff_utils import diff_fields
from json_validator import validate_json
from reporter import write_json_report, write_html_report

class UI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Avro Validator – Production")
        self.resize(900,650)
        l=QVBoxLayout(self)
        for t,f in [("Reference",lambda:self.pick("ref")),("New",lambda:self.pick("new")),("JSON",self.pick_json)]:
            b=QPushButton(f"Select {t}"); b.clicked.connect(f); l.addWidget(b)
        self.mode=QComboBox(); self.mode.addItems(["Backward","Forward","Full"]); l.addWidget(self.mode)
        v=QPushButton("Validate"); v.clicked.connect(self.validate); l.addWidget(v)
        self.out=QTextEdit(); l.addWidget(self.out)
        ej=QPushButton("Export JSON"); ej.clicked.connect(self.ej)
        eh=QPushButton("Export HTML"); eh.clicked.connect(self.eh)
        l.addWidget(ej); l.addWidget(eh)

    def pick(self,t):
        p,_=QFileDialog.getOpenFileName(self,"Select",".","Archives (*.jar *.zip)")
        if p: setattr(self,f"{t}_p",p)

    def pick_json(self):
        p,_=QFileDialog.getOpenFileName(self,"Select JSON",".","*.json")
        if p: self.json_p=p

    def validate(self):
        self.res={}
        ref=extract_schemas(self.ref_p); new=extract_schemas(self.new_p)
        for k in ref:
            if k not in new:
                self.res[k]={"breaking":["Schema missing"],"non_breaking":[]}
            else:
                nb,br=diff_fields(ref[k],new[k])
                br+=check_compatibility(ref[k],new[k],self.mode.currentText())
                self.res[k]={"breaking":br,"non_breaking":nb}
        self.out.clear()
        for s,d in self.res.items():
            self.out.append("\n"+s)
            for b in d["breaking"]: self.out.append("❌ "+b)
            for nb in d["non_breaking"]: self.out.append("⚠️ "+nb)
        if hasattr(self,"json_p"):
            m,t,f=validate_json(list(ref.values())[0],json.load(open(self.json_p)))
            self.out.append("\nJSON Validation")
            for x in m: self.out.append("Missing: "+x)
            for x in t: self.out.append("Type error: "+x)
            self.fixed=f

    def ej(self):
        p,_=QFileDialog.getSaveFileName(self,"Save",".","*.json")
        if p: write_json_report(self.res,p)

    def eh(self):
        p,_=QFileDialog.getSaveFileName(self,"Save",".","*.html")
        if p: write_html_report(self.res,p)

if __name__=="__main__":
    app=QApplication(sys.argv); UI().show(); sys.exit(app.exec())
