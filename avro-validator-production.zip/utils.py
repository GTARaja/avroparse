
def avro_type(t):
    if isinstance(t, list):
        return [x for x in t if x != "null"][0]
    return t
