
from utils import avro_type
def check_compatibility(old,new,mode):
    e=[]
    o={f["name"]:f for f in old["fields"]}
    n={f["name"]:f for f in new["fields"]}
    if mode in ("Backward","Full"):
        for f in o:
            if f not in n: e.append(f"Field removed: {f}")
        for f in o:
            if f in n and avro_type(o[f]["type"])!=avro_type(n[f]["type"]):
                e.append(f"Type changed: {f}")
        for f in n:
            if f not in o and "default" not in n[f]:
                e.append(f"New required field without default: {f}")
    if mode in ("Forward","Full"):
        for f in o:
            if f in n and avro_type(o[f]["type"])!=avro_type(n[f]["type"]):
                e.append(f"Forward incompatible type change: {f}")
    return e
