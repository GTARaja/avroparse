
from utils import avro_type
def default_value(f):
    if "default" in f: return f["default"]
    return {"string":"","int":0,"long":0,"float":0,"double":0,"boolean":False}.get(avro_type(f["type"]))
def validate_json(schema,data):
    fixed=dict(data); missing=[]; type_err=[]
    for f in schema["fields"]:
        n=f["name"]
        if n not in fixed:
            missing.append(n); fixed[n]=default_value(f)
        elif not isinstance(fixed[n],str) and avro_type(f["type"])=="string":
            type_err.append(n)
    return missing,type_err,fixed
