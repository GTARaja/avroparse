
def is_optional(field_type):
    return isinstance(field_type, list) and "null" in field_type

def check_compatibility(old_schema, new_schema, mode):
    errors = []

    old_fields = {f["name"]: f for f in old_schema.get("fields", [])}
    new_fields = {f["name"]: f for f in new_schema.get("fields", [])}

    if mode in ("Backward", "Full"):
        for field in old_fields:
            if field not in new_fields:
                errors.append(f"Field removed: {field}")

        for field, old_f in old_fields.items():
            if field in new_fields and old_f["type"] != new_fields[field]["type"]:
                errors.append(f"Type changed: {field}")

        for field, new_f in new_fields.items():
            if field not in old_fields:
                if not is_optional(new_f["type"]) and "default" not in new_f:
                    errors.append(f"New required field without default: {field}")

    if mode in ("Forward", "Full"):
        for field, old_f in old_fields.items():
            if field in new_fields and old_f["type"] != new_fields[field]["type"]:
                errors.append(f"Forward incompatible type change: {field}")

    return errors
