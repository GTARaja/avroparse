
import sys
from PyQt6.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton,
    QFileDialog, QVBoxLayout,
    QTextEdit, QComboBox, QMessageBox, QProgressBar
)
from PyQt6.QtCore import Qt

from jar_extractor import extract_avro_schemas
from compatibility import check_compatibility
from diff_utils import diff_fields
from reporter import write_json_report, write_html_report

class AvroValidatorUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Avro JAR Schema Validator (Stable)")
        self.setAcceptDrops(True)
        self.resize(850, 600)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        self.ref_label = QLabel("Reference JAR: Drag or Select")
        self.new_label = QLabel("New JAR: Drag or Select")

        btn_ref = QPushButton("Select Reference JAR")
        btn_new = QPushButton("Select New JAR")
        btn_ref.clicked.connect(lambda: self.select_jar("ref"))
        btn_new.clicked.connect(lambda: self.select_jar("new"))

        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["Backward", "Forward", "Full"])

        validate_btn = QPushButton("Validate")
        validate_btn.clicked.connect(self.validate)

        self.progress = QProgressBar()
        self.result_area = QTextEdit()
        self.result_area.setReadOnly(True)

        export_json = QPushButton("Export JSON Report")
        export_html = QPushButton("Export HTML Report")
        export_json.clicked.connect(self.export_json)
        export_html.clicked.connect(self.export_html)

        for w in [
            self.ref_label, btn_ref,
            self.new_label, btn_new,
            QLabel("Compatibility Mode"), self.mode_combo,
            validate_btn, self.progress,
            self.result_area,
            export_json, export_html
        ]:
            layout.addWidget(w)

        self.setLayout(layout)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        path = event.mimeData().urls()[0].toLocalFile()
        if not path.endswith(".jar"):
            return
        if not hasattr(self, "ref_jar"):
            self.ref_jar = path
            self.ref_label.setText(f"Reference JAR: {path}")
        else:
            self.new_jar = path
            self.new_label.setText(f"New JAR: {path}")

    def select_jar(self, jar_type):
        path, _ = QFileDialog.getOpenFileName(self, "Select JAR", "", "*.jar")
        if path:
            if jar_type == "ref":
                self.ref_jar = path
                self.ref_label.setText(f"Reference JAR: {path}")
            else:
                self.new_jar = path
                self.new_label.setText(f"New JAR: {path}")

    def validate(self):
        if not hasattr(self, "ref_jar") or not hasattr(self, "new_jar"):
            QMessageBox.warning(self, "Input Missing", "Select both JAR files")
            return

        self.progress.setValue(5)
        self.result_area.clear()
        self.results = {}

        ref = extract_avro_schemas(self.ref_jar)
        new = extract_avro_schemas(self.new_jar)
        mode = self.mode_combo.currentText()

        total = max(len(ref), 1)
        for i, name in enumerate(ref):
            self.progress.setValue(int((i / total) * 100))

            if name not in new:
                self.results[name] = {
                    "breaking": ["Schema missing in new JAR"],
                    "non_breaking": []
                }
                continue

            non_breaking, breaking = diff_fields(ref[name], new[name])
            breaking.extend(check_compatibility(ref[name], new[name], mode))

            self.results[name] = {
                "breaking": breaking,
                "non_breaking": non_breaking
            }

        self.progress.setValue(100)

        for schema, res in self.results.items():
            self.result_area.append(f"\n📘 {schema}")
            for b in res["breaking"]:
                self.result_area.append(f"❌ {b}")
            for nb in res["non_breaking"]:
                self.result_area.append(f"⚠️ {nb}")

        if not any(self.results[s]["breaking"] for s in self.results):
            self.result_area.append("\n✅ VALIDATION PASSED")

    def export_json(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save JSON", "", "*.json")
        if path:
            write_json_report(self.results, path)

    def export_html(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save HTML", "", "*.html")
        if path:
            write_html_report(self.results, path)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = AvroValidatorUI()
    win.show()
    sys.exit(app.exec())
