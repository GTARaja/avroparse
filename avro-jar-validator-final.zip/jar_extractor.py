
import zipfile
import json

def extract_avro_schemas(jar_path):
    schemas = {}
    with zipfile.ZipFile(jar_path, 'r') as jar:
        for name in jar.namelist():
            if name.endswith(".avsc"):
                raw = jar.read(name).decode("utf-8")
                schema = json.loads(raw)
                key = f"{schema.get('namespace', '')}.{schema['name']}"
                schemas[key] = schema
    return schemas
