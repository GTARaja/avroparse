
def diff_fields(old_schema, new_schema):
    non_breaking = []
    old_fields = {f["name"]: f for f in old_schema.get("fields", [])}
    new_fields = {f["name"]: f for f in new_schema.get("fields", [])}

    for field in new_fields:
        if field not in old_fields:
            non_breaking.append(f"New field added: {field}")

    return non_breaking, []
