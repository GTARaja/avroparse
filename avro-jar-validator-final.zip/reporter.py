
import json

def write_json_report(results, path):
    with open(path, "w") as f:
        json.dump(results, f, indent=2)

def write_html_report(results, path):
    html = "<html><body><h1>Avro Schema Validation Report</h1>"
    for schema, data in results.items():
        html += f"<h2>{schema}</h2>"
        if data["breaking"]:
            html += "<h3 style='color:red'>Breaking</h3><ul>"
            for b in data["breaking"]:
                html += f"<li>{b}</li>"
            html += "</ul>"
        if data["non_breaking"]:
            html += "<h3 style='color:orange'>Non-Breaking</h3><ul>"
            for nb in data["non_breaking"]:
                html += f"<li>{nb}</li>"
            html += "</ul>"
    html += "</body></html>"
    with open(path, "w") as f:
        f.write(html)
