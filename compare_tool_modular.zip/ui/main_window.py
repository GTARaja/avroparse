from PyQt6.QtWidgets import QMainWindow, QLabel

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Modular SQL / PL-SQL Compare Tool")
        self.setGeometry(200, 200, 800, 400)
        self.setCentralWidget(QLabel("UI wiring coming next step"))