FEATURES = {
    "file_compare": True,
    "folder_compare": True,
    "zip_compare": True,
    "html_report": True
}