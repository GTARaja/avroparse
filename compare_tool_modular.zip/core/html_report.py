import difflib

class HtmlReport:
    def generate(self, left, right, out_file):
        html = difflib.HtmlDiff().make_file(
            left.splitlines(),
            right.splitlines(),
            "Left",
            "Right"
        )
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(html)