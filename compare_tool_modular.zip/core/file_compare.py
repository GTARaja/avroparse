from core.diff_engine import DiffEngine

class FileComparator:
    def compare(self, left_text, right_text):
        return DiffEngine.compare_lines(
            left_text.splitlines(),
            right_text.splitlines()
        )