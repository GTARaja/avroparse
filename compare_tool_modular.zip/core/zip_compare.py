import zipfile, hashlib

def zip_hash(z, name):
    return hashlib.md5(z.read(name)).hexdigest()

class ZipComparator:
    def compare(self, zip1, zip2):
        result = {"only_left": [], "only_right": [], "modified": []}
        with zipfile.ZipFile(zip1) as z1, zipfile.ZipFile(zip2) as z2:
            f1, f2 = set(z1.namelist()), set(z2.namelist())
            result["only_left"] = list(f1 - f2)
            result["only_right"] = list(f2 - f1)
            for f in f1 & f2:
                if zip_hash(z1, f) != zip_hash(z2, f):
                    result["modified"].append(f)
        return result