import os, hashlib

def file_hash(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()

class FolderComparator:
    def compare(self, left_dir, right_dir):
        result = {"only_left": [], "only_right": [], "modified": []}
        left_files = set(os.listdir(left_dir))
        right_files = set(os.listdir(right_dir))

        result["only_left"] = list(left_files - right_files)
        result["only_right"] = list(right_files - left_files)

        for f in left_files & right_files:
            if file_hash(os.path.join(left_dir, f)) != file_hash(os.path.join(right_dir, f)):
                result["modified"].append(f)

        return result