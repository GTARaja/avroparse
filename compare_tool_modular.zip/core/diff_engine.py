import difflib

class DiffEngine:
    @staticmethod
    def compare_lines(left, right):
        return list(difflib.ndiff(left, right))