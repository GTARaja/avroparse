
import sys
from PyQt6.QtWidgets import QApplication
from ui_main import MainWindow

app = QApplication(sys.argv)
win = MainWindow()
win.show()
sys.exit(app.exec())
