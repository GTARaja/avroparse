
from PyQt6.QtWidgets import (
    QWidget, QPushButton, QTextEdit, QVBoxLayout, QFileDialog
)
import json
from avro_utils import fix_record

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Avro JSON Validator - Deep Support")

        self.log = QTextEdit()
        self.btn_schema = QPushButton("Load AVSC")
        self.btn_json = QPushButton("Load JSON")
        self.btn_fix = QPushButton("Validate & Auto-Fix")

        layout = QVBoxLayout()
        for b in (self.btn_schema, self.btn_json, self.btn_fix, self.log):
            layout.addWidget(b)
        self.setLayout(layout)

        self.schema = None
        self.json_data = None

        self.btn_schema.clicked.connect(self.load_schema)
        self.btn_json.clicked.connect(self.load_json)
        self.btn_fix.clicked.connect(self.fix_json)

    def load_schema(self):
        path, _ = QFileDialog.getOpenFileName(self, "Load AVSC", "", "*.avsc")
        if path:
            self.schema = json.load(open(path))
            self.log.append("Schema loaded")

    def load_json(self):
        path, _ = QFileDialog.getOpenFileName(self, "Load JSON", "", "*.json")
        if path:
            self.json_data = json.load(open(path))
            self.log.append("JSON loaded")

    def fix_json(self):
        if not self.schema or not self.json_data:
            self.log.append("Load schema and JSON first")
            return

        fixed = fix_record(self.json_data, self.schema)

        save_path, _ = QFileDialog.getSaveFileName(self, "Save Fixed JSON", "", "*.json")
        if save_path:
            json.dump(fixed, open(save_path, "w"), indent=2)
            self.log.append("Kafka-safe JSON saved")
