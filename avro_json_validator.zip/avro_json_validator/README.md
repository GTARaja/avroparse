# Avro JSON Validator
Supports deep nested records, arrays, unions and auto-fix.
