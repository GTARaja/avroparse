
def infer_default(avro_type):
    if isinstance(avro_type, list):
        non_null = [t for t in avro_type if t != "null"]
        return infer_default(non_null[0]) if non_null else None

    if isinstance(avro_type, dict):
        if avro_type["type"] == "record":
            return {f["name"]: infer_default(f["type"]) for f in avro_type["fields"]}
        if avro_type["type"] == "array":
            return []
        return None

    return {
        "string": "",
        "int": 0,
        "long": 0,
        "float": 0.0,
        "double": 0.0,
        "boolean": False
    }.get(avro_type)


def fix_record(data, schema):
    fixed = {}
    for field in schema["fields"]:
        name = field["name"]
        ftype = field["type"]

        if name in data:
            fixed[name] = validate_and_fix(data[name], ftype)
        else:
            fixed[name] = field.get("default", infer_default(ftype))
    return fixed


def validate_and_fix(value, avro_type):
    if isinstance(avro_type, list):
        for t in avro_type:
            if t == "null" and value is None:
                return None
            try:
                return validate_and_fix(value, t)
            except:
                continue
        return infer_default(avro_type)

    if isinstance(avro_type, dict):
        if avro_type["type"] == "record":
            return fix_record(value or {}, avro_type)
        if avro_type["type"] == "array":
            if not isinstance(value, list):
                return []
            return [validate_and_fix(v, avro_type["items"]) for v in value]

    return value
