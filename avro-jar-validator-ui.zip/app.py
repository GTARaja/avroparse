
import sys
from PyQt6.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton,
    QFileDialog, QVBoxLayout, QHBoxLayout,
    QTextEdit, QComboBox, QMessageBox, QProgressBar
)
from PyQt6.QtCore import Qt

from jar_extractor import extract_avro_schemas
from compatibility import check_compatibility, BACKWARD, FORWARD, FULL
from diff_utils import diff_fields
from reporter import write_json_report, write_html_report


class AvroValidatorUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Avro JAR Schema Validator")
        self.setAcceptDrops(True)
        self.resize(800, 600)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        self.ref_label = QLabel("Reference JAR: Drag or Select")
        self.new_label = QLabel("New JAR: Drag or Select")

        btn_ref = QPushButton("Select Reference JAR")
        btn_new = QPushButton("Select New JAR")

        btn_ref.clicked.connect(lambda: self.select_jar("ref"))
        btn_new.clicked.connect(lambda: self.select_jar("new"))

        self.mode_combo = QComboBox()
        self.mode_combo.addItems([BACKWARD, FORWARD, FULL])

        self.validate_btn = QPushButton("Validate")
        self.validate_btn.clicked.connect(self.validate)

        self.progress = QProgressBar()
        self.progress.setValue(0)

        self.result_area = QTextEdit()
        self.result_area.setReadOnly(True)

        export_json = QPushButton("Export JSON")
        export_html = QPushButton("Export HTML")

        export_json.clicked.connect(self.export_json)
        export_html.clicked.connect(self.export_html)

        layout.addWidget(self.ref_label)
        layout.addWidget(btn_ref)
        layout.addWidget(self.new_label)
        layout.addWidget(btn_new)
        layout.addWidget(QLabel("Compatibility Mode"))
        layout.addWidget(self.mode_combo)
        layout.addWidget(self.validate_btn)
        layout.addWidget(self.progress)
        layout.addWidget(self.result_area)
        layout.addWidget(export_json)
        layout.addWidget(export_html)

        self.setLayout(layout)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        path = event.mimeData().urls()[0].toLocalFile()
        if not path.endswith(".jar"):
            return
        if not hasattr(self, "ref_jar"):
            self.ref_jar = path
            self.ref_label.setText(f"Reference JAR: {path}")
        else:
            self.new_jar = path
            self.new_label.setText(f"New JAR: {path}")

    def select_jar(self, jar_type):
        path, _ = QFileDialog.getOpenFileName(self, "Select JAR", "", "*.jar")
        if path:
            if jar_type == "ref":
                self.ref_jar = path
                self.ref_label.setText(f"Reference JAR: {path}")
            else:
                self.new_jar = path
                self.new_label.setText(f"New JAR: {path}")

    def validate(self):
        if not hasattr(self, "ref_jar") or not hasattr(self, "new_jar"):
            QMessageBox.warning(self, "Missing Input", "Select both JARs")
            return

        self.progress.setValue(10)
        self.results = {}
        self.result_area.clear()

        ref = extract_avro_schemas(self.ref_jar)
        new = extract_avro_schemas(self.new_jar)
        mode = self.mode_combo.currentText()

        total = len(ref)
        for idx, name in enumerate(ref):
            self.progress.setValue(int((idx / total) * 100))
            if name not in new:
                self.results[name] = {
                    "breaking": ["Schema missing in new jar"],
                    "non_breaking": []
                }
                continue

            nb, br = diff_fields(ref[name], new[name])
            compat_err = check_compatibility(ref[name], new[name], mode)
            br.extend(compat_err)

            self.results[name] = {
                "breaking": br,
                "non_breaking": nb
            }

        self.progress.setValue(100)

        for schema, res in self.results.items():
            self.result_area.append(f"\n📘 {schema}")
            for b in res["breaking"]:
                self.result_area.append(f"❌ {b}")
            for nb in res["non_breaking"]:
                self.result_area.append(f"⚠️ {nb}")

        if not any(self.results[s]["breaking"] for s in self.results):
            self.result_area.append("\n✅ VALIDATION PASSED")

    def export_json(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save JSON", "", "*.json")
        if path:
            write_json_report(self.results, path)

    def export_html(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save HTML", "", "*.html")
        if path:
            write_html_report(self.results, path)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = AvroValidatorUI()
    win.show()
    sys.exit(app.exec())
