
def diff_fields(old_schema, new_schema):
    diffs = []
    breaking = []

    old_fields = {f["name"]: f for f in old_schema.get("fields", [])}
    new_fields = {f["name"]: f for f in new_schema.get("fields", [])}

    for field in old_fields:
        if field not in new_fields:
            breaking.append(f"Field removed: {field}")
        else:
            if old_fields[field]["type"] != new_fields[field]["type"]:
                breaking.append(
                    f"Type change: {field} "
                    f"{old_fields[field]['type']} → {new_fields[field]['type']}"
                )

    for field in new_fields:
        if field not in old_fields:
            diffs.append(f"New field added: {field}")

    return diffs, breaking
