
from fastavro.schema import check_schema_compatibility

BACKWARD = "Backward"
FORWARD = "Forward"
FULL = "Full"

def check_compatibility(old_schema, new_schema, mode):
    errors = []
    try:
        if mode in (BACKWARD, FULL):
            check_schema_compatibility(old_schema, new_schema)
        if mode in (FORWARD, FULL):
            check_schema_compatibility(new_schema, old_schema)
    except Exception as e:
        errors.append(str(e))
    return errors
