
import zipfile, json, os

def extract_schemas(path):
    schemas = {}

    def read_avsc(data):
        s = json.loads(data)
        key = f"{s.get('namespace','')}.{s['name']}"
        schemas[key] = s

    if os.path.isdir(path):
        for root,_,files in os.walk(path):
            for f in files:
                if f.endswith(".avsc"):
                    with open(os.path.join(root,f)) as fh:
                        read_avsc(fh.read())

    elif zipfile.is_zipfile(path):
        with zipfile.ZipFile(path,'r') as z:
            for n in z.namelist():
                if n.endswith(".avsc"):
                    read_avsc(z.read(n).decode("utf-8"))
    else:
        raise ValueError("Unsupported input")

    return schemas
