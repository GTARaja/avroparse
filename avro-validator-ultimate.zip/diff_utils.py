
def diff(old,new,ignore_fn):
    nb=[]; of={f["name"] for f in old["fields"]}
    for f in new["fields"]:
        if f["name"] not in of and not ignore_fn(f["name"]):
            nb.append(f"New field added: {f['name']}")
    return nb
