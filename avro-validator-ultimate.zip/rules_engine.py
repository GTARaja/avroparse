
import yaml, re

def load_rules(path):
    with open(path) as f:
        return yaml.safe_load(f)

def is_ignored(schema, field, rules):
    for p in rules.get("ignore_schemas", []):
        if re.match(p, schema):
            return True
    return field in rules.get("ignore_fields", [])
