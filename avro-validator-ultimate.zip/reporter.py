
import json, csv

def export_all(rows,path,fmt):
    if fmt=="json":
        with open(path,"w") as f: json.dump(rows,f,indent=2)
    if fmt=="csv":
        with open(path,"w",newline="") as f:
            w=csv.DictWriter(f,rows[0].keys()); w.writeheader(); w.writerows(rows)
    if fmt=="html":
        html="<table border=1><tr>"+''.join(f"<th>{k}</th>" for k in rows[0])+"</tr>"
        for r in rows:
            html+="<tr>"+''.join(f"<td>{v}</td>" for v in r.values())+"</tr>"
        html+="</table>"
        open(path,"w").write(html)
