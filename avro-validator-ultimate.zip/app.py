
import sys
from PyQt6.QtWidgets import *
from PyQt6.QtGui import QColor
from schema_extractor import extract_schemas
from compatibility import check
from diff_utils import diff
from rules_engine import load_rules, is_ignored
from reporter import export_all

class App(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Avro Validator – Ultimate")
        self.resize(1200,700)
        self.rules=load_rules("rules.yaml")
        self.init_ui()

    def table(self):
        t=QTableWidget(0,4)
        t.setHorizontalHeaderLabels(["Schema","Type","Change","Severity"])
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        return t

    def init_ui(self):
        l=QVBoxLayout()
        self.ref=QLabel("Reference")
        self.new=QLabel("New")
        for t in ("ref","new"):
            b=QPushButton(f"Select {t}")
            b.clicked.connect(lambda _,x=t:self.pick(x))
            l.addWidget(getattr(self,t)); l.addWidget(b)

        self.mode=QComboBox(); self.mode.addItems(["Backward","Forward","Full"])
        l.addWidget(self.mode)

        self.search=QLineEdit(); self.search.setPlaceholderText("Search")
        self.search.textChanged.connect(self.filter)
        l.addWidget(self.search)

        self.tabs=QTabWidget()
        self.all=self.table(); self.br=self.table(); self.nb=self.table()
        self.tabs.addTab(self.all,"All")
        self.tabs.addTab(self.br,"Breaking")
        self.tabs.addTab(self.nb,"Non-Breaking")
        l.addWidget(self.tabs)

        v=QPushButton("Validate"); v.clicked.connect(self.validate)
        l.addWidget(v)

        e=QPushButton("Export CSV/JSON/HTML"); e.clicked.connect(self.export)
        l.addWidget(e)

        self.setLayout(l)

    def pick(self,t):
        p,_=QFileDialog.getExistingDirectory(self,"Select Folder")
        if not p:
            p,_=QFileDialog.getOpenFileName(self,"Select",".","*.jar *.zip")
        setattr(self,f"{t}_p",p); getattr(self,t).setText(p)

    def add(self,tab,schema,typ,msg,sev):
        r=tab.rowCount(); tab.insertRow(r)
        for c,v in enumerate([schema,typ,msg,sev]):
            tab.setItem(r,c,QTableWidgetItem(v))
        if sev=="HIGH":
            for c in range(4): tab.item(r,c).setBackground(QColor("#ffb3b3"))

    def validate(self):
        self.all.setRowCount(0); self.br.setRowCount(0); self.nb.setRowCount(0)
        r=extract_schemas(self.ref_p); n=extract_schemas(self.new_p)
        rows=[]
        for s in r:
            ignore=lambda f:is_ignored(s,f,self.rules)
            if s not in n:
                self.add(self.all,s,"BREAKING","Schema missing","HIGH")
                self.add(self.br,s,"BREAKING","Schema missing","HIGH")
                rows.append({"schema":s,"type":"BREAKING","change":"Schema missing","severity":"HIGH"})
                continue
            for e in check(r[s],n[s],self.mode.currentText(),ignore):
                self.add(self.all,s,"BREAKING",e,"HIGH")
                self.add(self.br,s,"BREAKING",e,"HIGH")
                rows.append({"schema":s,"type":"BREAKING","change":e,"severity":"HIGH"})
            for nb in diff(r[s],n[s],ignore):
                self.add(self.all,s,"NON-BREAKING",nb,"LOW")
                self.add(self.nb,s,"NON-BREAKING",nb,"LOW")
                rows.append({"schema":s,"type":"NON-BREAKING","change":nb,"severity":"LOW"})
        self.rows=rows

    def filter(self,t):
        for tab in (self.all,self.br,self.nb):
            for r in range(tab.rowCount()):
                tab.setRowHidden(r,t.lower() not in " ".join(tab.item(r,c).text().lower() for c in range(4)))

    def export(self):
        p,_=QFileDialog.getSaveFileName(self,"Export",".","*.csv *.json *.html")
        if p.endswith(".csv"): export_all(self.rows,p,"csv")
        if p.endswith(".json"): export_all(self.rows,p,"json")
        if p.endswith(".html"): export_all(self.rows,p,"html")

if __name__=="__main__":
    app=QApplication(sys.argv)
    w=App(); w.show()
    sys.exit(app.exec())
