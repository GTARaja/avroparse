
# Avro Validator – Ultimate Enterprise Edition

## Features
- JAR / ZIP / Folder support
- Breaking / Non-Breaking / All tabs
- Color-coded tables
- Live search & filters
- Per-schema summary panel
- YAML-based ignore rules
- CSV / JSON / HTML export
- Drag & Drop
- Backward / Forward / Full compatibility
- Deterministic (no fastavro dependency)

## Run
pip install -r requirements.txt
python app.py
