
def is_optional(t):
    return isinstance(t,list) and "null" in t

def check(old,new,mode,ignore_fn):
    errs=[]; of={f["name"]:f for f in old["fields"]}; nf={f["name"]:f for f in new["fields"]}
    if mode in ("Backward","Full"):
        for f in of:
            if f not in nf and not ignore_fn(f):
                errs.append(f"Field removed: {f}")
        for f in of:
            if f in nf and of[f]["type"]!=nf[f]["type"] and not ignore_fn(f):
                errs.append(f"Type changed: {f}")
        for f in nf:
            if f not in of and not is_optional(nf[f]["type"]) and "default" not in nf[f]:
                errs.append(f"New required field: {f}")
    if mode in ("Forward","Full"):
        for f in of:
            if f in nf and of[f]["type"]!=nf[f]["type"]:
                errs.append(f"Forward incompatible: {f}")
    return errs
